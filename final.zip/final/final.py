from tkinter import *
from PIL import ImageTk, Image
import numpy as np
from keras.models import load_model
import numpy as np
import matplotlib.pyplot as plt
from keras.utils.image_utils import load_img, img_to_array

model100 = load_model('license_plate_cnn.h5')

def CTCHINH():

	root1 = Tk()
	root1.title("Results")
	root1.geometry("240x120")
	img = load_img('pic(6).jpg',target_size= (64,64))
	plt.imshow(img)
	img = img_to_array(img)
	img = img.reshape(1,64,64,3)
	img = img.astype('float32')
	img = img/255
	a = np.argmax(model100.predict(img), axis = -1)
	if (a == 1):
		myLabel10 = Label(root1, text="license_plate", font="Arial 13 bold", fg="red")
		myLabel10.place(x = 100, y = 50,anchor = CENTER)
	else:
		myLabel11 = Label(root1, text="license_plate_car", font="Arial 13 bold", fg="red")
		myLabel11.place(x = 100, y = 50,anchor = CENTER)
	plt.show()
	root1.mainloop()
	
# Tạo cửa sổ giao diện chính
root = Tk()
root.title("Program Interface")
root.geometry("1366x720")

lgtruong = ImageTk.PhotoImage(Image.open("logotruong.png"))
lblgtruong = Label(image= lgtruong)
lblgtruong.place(x = 20, y = 5)

lgkhoa = Image.open("logokhoa.png")
resize_down1 = lgkhoa.resize((112,105))
lgkhoa_re = ImageTk.PhotoImage(resize_down1)
lblgkhoa = Label(image= lgkhoa_re)
lblgkhoa.place(x = 1150, y = 60,anchor = CENTER)

myLabel2 = Label(root, text="Faculty Of Mechanical Engineering", font="Arial 15 bold", fg="darkblue")
myLabel3 = Label(root, text="Mechatronics Engineering", font="Arial 15 bold", fg="darkblue")
myLabel2.place(x = 1150, y = 130,anchor = CENTER)
myLabel3.place(x = 1150, y = 160,anchor = CENTER)

anh2 = Image.open("detai2.png")
resize_down2 = anh2.resize((635,376))
anh2_re = ImageTk.PhotoImage(resize_down2)
lbanh2 = Label(image= anh2_re)
lbanh2.place(x = 5, y = 420)

anh1 = Image.open("detai1.png")
resize_down3 = anh1.resize((647,357))
anh1_re = ImageTk.PhotoImage(resize_down3)
lbanh1 = Label(image= anh1_re)
lbanh1.place(x = 200, y = 230)


myLabel4 = Label(root, text="Automated License Plate Recognition", font="Arial 23 bold", fg="red")
myLabel4.place(x = 683, y = 200,anchor = CENTER)

myLabel5 = Label(root, text="Subject: Artificial Intelligence", font="Arial 15 bold")
myLabel6 = Label(root, text="Instructors: PGS. Nguyen Truong Thinh", font="Arial 15 bold")
myLabel5.place(x = 1150, y = 300,anchor = CENTER)
myLabel6.place(x = 1150, y = 330,anchor = CENTER)

myLabel7 = Label(root, text="Author:", font="Arial 15 bold", fg="darkblue")
myLabel8 = Label(root, text="Ho Dinh Khanh - 20146088", font="Arial 15 bold")

myLabel7.place(x = 1000, y = 380)
myLabel8.place(x = 1000, y =420)

btnLaunch = Button(root,text="START",font="Arial 30 bold", fg="red", command=CTCHINH)
btnLaunch.place(x = 1150, y =500, anchor = CENTER)
btnStop = Button(root,text="QUIT",font="Arial 30 bold", fg="red", command=root.destroy)
btnStop.place(x = 1150, y =600, anchor = CENTER)
# Gọi vòng lặp sự kiện chính để các hành động có thể diễn ra trên màn hình máy tính của người dùng
root.mainloop()